
// Cards Constructor function which has rank and suit 
function cards(r, s)
{
this.rank = r;
this.suit = s;
this.cardName = r  + " of "  +  s;
} 

// end of Card constructor function


suits = ["Spades","Hearts", "Diamonds","Clubs"]  // creating a array of suits which has "Spades,Hearts,Diamonds,Clubs"
ranks ="A2345678910JQK" // Creating a string to represent the ranks
deck = new Array(ranks.length * suits.length);//created a new array for deck to have the ranks and suits of cards

// Function to get the deck of cards
function getdeck()
{
for(i=0;i<suits.length;i++)
{
for(j=0;j<ranks.length;j++)
deck[ranks.length*i+j] = new cards(ranks[j],suits[i]); // to get the index of cards in deck in form of array
}
return deck;
}

// Function to show the deck of cards 
function showCards(arr,pr,id)
{
  for (var i = 0; i < eval(arr + ".length"); i++)
  {
    var node = document.createElement("div");
    var textnode = document.createTextNode(eval(arr + "[i]" + "." + pr));
    node.appendChild(textnode);
    document.getElementById(id).appendChild(node);
  }
}


decks =getdeck();
showCards("decks","cardName","unshuffle-deck");


// shuffle function for shuffling the deck of cards
function shuffle(arr) 
{
  var c = arr.length,a, i;

  while(c) 
  {
    i = Math.floor(Math.random() * c--);

    // Swaping it with the current element.
    a = arr[c];
    arr[c] = arr[i];
    arr[i] = a;
  }

  return arr;
}


// show Shuffle function
function showshuffle()
{
decks = getdeck();
shuffle(decks);
document.getElementById("shuffle-deck").innerHTML ="";
showCards("decks","cardName","shuffle-deck");
document.getElementById("deal_cards").innerHTML ="";

}

document.getElementById("shuffle").addEventListener("click",showshuffle);


function showHand() {
	if (decks.length < 5)
  	showshuffle();
  else{
  dealCards = Deal(decks, 5);
  showCards("dealCards", "cardName", "deal_cards");
  document.getElementById("shuffle-deck").innerHTML = "";
  showCards("decks", "cardName","shuffle-deck");
  }
}


function Deal(d, n) {
var oneHand = [];
  if (d.length > n){
  	for (i = 0; i < n; i++){
      oneHand[i] = d.shift();
     } 
		return oneHand;
    }
  else
    return null;
}


document.getElementById("deal_btn").addEventListener("click", showHand);
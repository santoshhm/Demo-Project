 /* Finds the index of the first occurence of item in the array, and -1 if not found */
if (Array.indexOf === undefined) {
    Array.prototype.indexOf = function(v) {
        for (var i = 0; i < this.length; ++i) {
            if (this[i] === v) {
                return i;
            }
        }
        return - 1;
    };
}

 // The playing card library core object
 (function(window,document,undefined){

    var playingCards = window.playingCards = function(conf) {
        var c = objExtend(playingCards.defaults, conf);
        if (! (this instanceof playingCards)) {
            // in jquery mode
            c.el = $(this); // capture the context (this will be the cardTable/Deck element)
            return new playingCards(c);
        }
        this.conf = c;
        this.init();
        if (this.conf.startShuffled) {
            this.shuffle(5);
        }
        return this;
    };
  
     //Object function to builds the deck
     
    playingCards.prototype.init = function() {
        this.cards = [];
        var o = this.conf,l,i,s,r,j;
        // populate deck draw
        for (i = 0; i < o.decks; i++) {
           
            for (s in o.suits) {
                for (r in o.ranks) {
                    l = this.cards.length;
                    this.cards[l] = new playingCards.card(r, o.ranks[r], s, o.suits[s]);
                }
            }
            // get the jokers card
            for (j = 0; j < o.jokers; j++) {
                l = this.cards.length;
                // suit will always be 1 or 2
                this.cards[l] = new playingCards.card("N", o.jokerText, (j % 2) + 1, '');
            }
        }
    };
   
   
    // To display and spread the cards in web page
    playingCards.prototype.spread = function(dest) {
        if (!this.conf.el && !dest) {
            return false;
        }
        var to = this.conf.el || dest,
            l = this.cards.length,
            i;
        to.html('');
        
        
    };
    // configuration to display the different cards in deck
    
    playingCards.defaults = {
        "decks": 1,
        "renderMode": 'css',
        "startShuffled": true,
        "jokers": 2,
        "jokerText": "Joker",
        "ranks": {
            "2": "Two",
            "3": "Three",
            "4": "Four",
            "5": "Five",
            "6": "Six",
            "7": "Seven",
            "8": "Eight",
            "9": "Nine",
            "10": "Ten",
            "J": "Jack",
            "Q": "Queen",
            "K": "King",
            "A": "Ace"
        },
        "suits": {
            "S": "Spades",
            "D": "Diamonds",
            "C": "Clubs",
            "H": "Hearts"
        }
    };

// 
// Cards object function which has rank and suit 
    playingCards.card = function(rank, rankString, suit, suitString, conf) {
        if (! (this instanceof playingCards.card)) {
            return new playingCards.card(rank, rankString, suit, suitString, conf);
        }

        this.conf = objExtend(playingCards.card.defaults, conf);

        if (suit === undefined) {
            //Arguments are rank, suit
            suit = rankString;
            rankString = playingCards.defaults.ranks[rank];
            suitString = playingCards.defaults.suits[suit];
        }

        this.rank = rank;
        this.rankString = rankString;
        this.suit = suit;
        this.suitString = suitString;
        return this;
    };
	
    // configuration to get individual cards face
    playingCards.card.defaults = {
        "singleFace": false
        // false will use a different image for each suit/face,  but if true will use diamond image for all
    };
   
   // Draw function to draw card 
    playingCards.prototype.draw = function() {
        return this.cards.length > 0 ? this.cards.pop() : null;
    };

	
	// add a card to the deck.
    playingCards.prototype.addCard = function(card) {
        this.cards.push(card);
    };
    
	
	// Count function to return the length of  cards in deck
    playingCards.prototype.count = function() {
        return this.cards.length;
    };
  // shuffle function for shuffling the deck of cards
    playingCards.prototype.shuffle = function(n) {
        if (!n) {
            n = 5;
        }
        var l = this.cards.length,
            r,tmp,i,j;

        for (i = 0; i < n; i++) {
            for (j = 0; j < l; j++) {
                r = Math.floor(Math.random() * l);
				
				  // Swaping cards with the current element.
                tmp = this.cards[j];
                this.cards[j] = this.cards[r];
                this.cards[r] = tmp;
            }
        }
    };

    
 // Object function to get the suit order 
    playingCards.prototype.orderBySuit = function() {
        this.init();
    } 
    
   // object extend to override default settings
     
    function objExtend(o, ex) {
        if (!ex) {
            return o;
        }
        for (var p in ex) {
            o[p] = ex[p];
        }
        return o;
    }  

})(this,this.document);





